package com.example;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        double fieldWidth = 400;
        double fieldHeight = 300;
        int radius = 10;

        Circle ball = new Circle(radius, Color.RED);
        ball.setCenterX(fieldWidth / 2);
        ball.setCenterY(fieldHeight / 2);

        Pane pane = new Pane(ball);
        Scene scene = new Scene(pane, fieldWidth, fieldHeight);

        AnimationTimer timer = new AnimationTimer() {
            private double dx = 3, dy = 3; // X Y speed

            @Override
            public void handle(long now) {
                double nextX = ball.getCenterX() + dx;
                double nextY = ball.getCenterY() + dy;

                if (nextX - radius < 0 || nextX + radius > fieldWidth) dx = -dx;
                if (nextY - radius < 0 || nextY + radius > fieldHeight) dy = -dy;

                ball.setCenterX(ball.getCenterX() + dx);
                ball.setCenterY(ball.getCenterY() + dy);
            }
        };
        timer.start();

        primaryStage.setTitle("JavaFX Bouncing Ball Animation");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
