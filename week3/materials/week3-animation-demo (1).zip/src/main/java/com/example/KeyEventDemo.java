package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class KeyEventDemo extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Label label = new Label("Press any key...");
        StackPane root = new StackPane(label);
        Scene scene = new Scene(root, 300, 200);

        // Add key event handlers to the scene
        scene.setOnKeyPressed(e -> {
            label.setText("Key Pressed: " + e.getCode());
        });
        scene.setOnKeyReleased(e -> {
            label.setText("Key Released: " + e.getCode());
        });
        scene.setOnKeyTyped(e -> {
            label.setText("Key Typed: " + e.getCharacter());
        });

        primaryStage.setTitle("JavaFX Key Event Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
        // Request focus so scene gets the key events
        root.requestFocus();
    }
}
