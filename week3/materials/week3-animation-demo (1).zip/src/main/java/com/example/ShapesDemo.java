package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class ShapesDemo extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Circle
        Circle circle = new Circle(50, Color.RED); // radius = 50, filled red
        circle.setCenterX(100);
        circle.setCenterY(100);

        // Rectangle
        Rectangle rect = new Rectangle(50, 50, 100, 60); // x, y, width, height
        rect.setFill(Color.BLUE);
        rect.setStroke(Color.BLACK);
        rect.setStrokeWidth(2);

        Pane pane = new Pane();
        pane.getChildren().addAll(circle, rect);

        Scene scene = new Scene(pane, 250, 200);
        primaryStage.setTitle("JavaFX Shapes Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
