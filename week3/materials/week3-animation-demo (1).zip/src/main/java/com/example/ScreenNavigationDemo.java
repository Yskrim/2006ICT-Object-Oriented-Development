package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ScreenNavigationDemo extends Application {

    private StackPane root;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        root = new StackPane();
        Scene scene = new Scene(root, 400, 300);
        showMainScreen();
        primaryStage.setTitle("JavaFX Multi-Screen Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showMainScreen() {
        VBox mainScreen = new VBox(10);
        mainScreen.setPadding(new Insets(20));
        Label mainLabel = new Label("Main Screen");
        Button screen1Button = new Button("Go to Screen 1");
        Button screen2Button = new Button("Go to Screen 2");
        screen1Button.setOnAction(e -> showScreen1());
        screen2Button.setOnAction(e -> showScreen2());
        mainScreen.getChildren().addAll(mainLabel, screen1Button, screen2Button);
        root.getChildren().setAll(mainScreen); // Replace current view
    }

    private void showScreen1() {
        VBox screen1 = new VBox(10);
        screen1.setPadding(new Insets(20));
        Label label = new Label("Screen 1");
        Button backButton = new Button("Back to Main");
        backButton.setOnAction(e -> showMainScreen());
        screen1.getChildren().addAll(label, backButton);
        root.getChildren().setAll(screen1);
    }

    private void showScreen2() {
        VBox screen2 = new VBox(10);
        screen2.setPadding(new Insets(20));
        Label label = new Label("Screen 2");
        Button backButton = new Button("Back to Main");
        backButton.setOnAction(e -> showMainScreen());
        screen2.getChildren().addAll(label, backButton);
        root.getChildren().setAll(screen2);
    }
}
